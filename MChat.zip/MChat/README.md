# MChat App
Realtime chat app with websockets using Node.js, Express and Socket.io with Vanilla JS on the frontend with a custom UI
## Usage
```
npm install
npm run dev

Go to localhost:3000# MChat

# MChat >> README.md
git init
git add README.md
git commit -m "first commit"
git branch -M MChat
git remote add origin https://github.com/ManishEmpire-2007/MChat.git
git push -u origin MChat